import pic1 from "../assets/bakery1.jpeg"
import pic2 from "../assets/bakery2.jpeg"
import pic3 from "../assets/bakery3.jpeg"
import pic4 from "../assets/bakery4.jpeg"



const products = [
    {
        id: 1,
        name: 'Bakery chef',
        distance: 'Driving distance of 20 meters',
        image: pic1,
        describtion: "this is a lifesaver!",
    },
    {
        id: 2,
        name: 'Queens Bakery',
        distance: 'Driving distance of 400 meters',
        image: pic2,
        describtion: "this is a lifesaver!",

    },
    {
        id: 3,
        name: 'Samantha Bakery',
        distance: 'Driving distance of 10 meters',
        image: pic3,
        describtion: "this is a lifesaver!",

    },
    {
        id: 4,
        name: 'Dowell bakery',
        distance: 'Driving distance of 4 meters',
        image: pic4,
        describtion: "this is a lifesaver!",
    },
    {
        id: 5,
        name: 'Bakery chef',
        distance: 'Driving distance of 20 meters',
        image: pic1,
        describtion: "this is a lifesaver!",
    },
    {
        id: 6,
        name: 'Queens Bakery',
        distance: 'Driving distance of 400 meters',
        image: pic2,
        describtion: "this is a lifesaver!",

    },
    {
        id: 7,
        name: 'Samantha Bakery',
        distance: 'Driving distance of 10 meters',
        image: pic3,
        describtion: "this is a lifesaver!",

    },
    {
        id: 8,
        name: 'Dowell bakery',
        distance: 'Driving distance of 4 meters',
        image: pic4,
        describtion: "this is a lifesaver!",
    },
    {
        id: 9,
        name: 'Bakery chef',
        distance: 'Driving distance of 20 meters',
        image: pic1,
        describtion: "this is a lifesaver!",
    },
    {
        id: 10,
        name: 'Queens Bakery',
        distance: 'Driving distance of 400 meters',
        image: pic2,
        describtion: "this is a lifesaver!",

    },
    {
        id: 11,
        name: 'Samantha Bakery',
        distance: 'Driving distance of 10 meters',
        image: pic3,
        describtion: "this is a lifesaver!",

    },
    {
        id: 12,
        name: 'Dowell bakery',
        distance: 'Driving distance of 4 meters',
        image: pic4,
        describtion: "this is a lifesaver!",
    },
];

export default products;